package br.edu.utfpr.rafaelproenca.aroma_library.enums;

public enum Projecao {
    Fraca,
    Moderada,
    Forte
}
