package br.edu.utfpr.rafaelproenca.aroma_library.modelo.enums;

public enum Genero {
    Masculino,
    Feminino,
    Unissex
}
