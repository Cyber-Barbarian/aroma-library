package br.edu.utfpr.rafaelproenca.aroma_library.modelo.enums;

public enum Longevidade {
    Curta,
    Media,
    Longa
}
