package br.edu.utfpr.rafaelproenca.aroma_library.enums;

public enum Longevidade {
    Curta,
    Media,
    Longa
}
