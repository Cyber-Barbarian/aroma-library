package br.edu.utfpr.rafaelproenca.aroma_library.enums;

public enum Genero {
    Masculino,
    Feminino,
    Unissex
}
